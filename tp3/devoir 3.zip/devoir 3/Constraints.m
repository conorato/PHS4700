classdef Constraints
    enumeration
        None,
        Ground,
        CanTopFace,
        CanBottomFace,
        CanSide,
        CanTopCorner,
        CanBottomCorner
    end
end