classdef GameObject 
   enumeration
      Ball,
      Can
   end
end